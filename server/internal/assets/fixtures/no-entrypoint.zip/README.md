archive that does not have an entrypoint
