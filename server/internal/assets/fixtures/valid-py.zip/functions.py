def handle_tool_call():
    pass
