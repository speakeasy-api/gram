#!/usr/bin/env bash
# SessionStart hook for Gram plugin
# Notifies user if GRAM_API_KEY is not configured

# Ensure standard paths are available
export PATH="/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"

# Setup Gram directories
GRAM_DIR="$HOME/.gram"
GRAM_CONFIG_FILE="$GRAM_DIR/config"

mkdir -p "$GRAM_DIR"

# Load user configuration if it exists
if [ -f "$GRAM_CONFIG_FILE" ]; then
  source "$GRAM_CONFIG_FILE"
fi

# Check if GRAM_API_KEY is set and show message if not
if [ -z "$GRAM_API_KEY" ]; then
  echo "GRAM_API_KEY is not set (session_start.sh)" >> /tmp/gram-hooks-debug.log
  cat << 'EOF'
{
  "continue": false,
  "stopReason": "GRAM_API_KEY is not set! Please run /gram login to continue.",
  "hookSpecificOutput": {
    "hookEventName": "SessionStart",
    "additionalContext": "⚠️  The Gram plugin is installed but not configured. Use the skill 'gram' and run '/gram login' to set up your API key."
  }
}
EOF
  exit 0
fi

# Successfully configured - allow session to continue
exit 0
