#!/usr/bin/env bash
# Shared script to send hook events to Gram

curl -X POST \
  -H "Content-Type: application/json" \
  -d @- \
  --max-time 30 \
  "https://app.getgram.ai/rpc/hooks.claude"
