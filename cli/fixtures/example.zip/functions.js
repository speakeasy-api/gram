export async function handleToolCall({ name, input }) {
  switch (name) {
    case "create_pet":
      return new Response(JSON.stringify({ input }));
    default:
      return new Response(JSON.stringify({ error: "Unknown tool" }), {
        status: 400,
      });
  }
}

export async function handleResources({ uri, input }) {
  if (uri === "resource://documentation.md") {
    return getDocumentationResource();
  }

  if (uri === "file:///example.png") {
    return getExampleImageResource();
  }

  if (uri === "file://example-code.js") {
    return getExampleCodeResource();
  }

  throw new Error(`Unknown resource: ${uri}`);
}

function getDocumentationResource() {
  const content = "# API Documentation\n\nThis is the main documentation resource.\n\n## Available Endpoints\n\n- GET /products\n- POST /charges";
  return new Response(content, {
    headers: { "Content-Type": "text/markdown" }
  });
}

function getExampleImageResource() {
  // 1x1 red pixel PNG as bytes
  const imageBytes = new Uint8Array([
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
    0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
    0x08, 0x02, 0x00, 0x00, 0x00, 0x90, 0x77, 0x53, 0xde, 0x00, 0x00, 0x00,
    0x0c, 0x49, 0x44, 0x41, 0x54, 0x08, 0xd7, 0x63, 0xf8, 0xcf, 0xc0, 0xf0,
    0x1f, 0x00, 0x05, 0x05, 0x02, 0x00, 0x5f, 0xc8, 0xf1, 0xd2, 0x00, 0x00,
    0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae, 0x42, 0x60, 0x82
  ]);
  return new Response(imageBytes, {
    headers: { "Content-Type": "image/png" }
  });
}

function getExampleCodeResource() {
  const jsCode = `// Example: Fetching user data
async function fetchUser(userId) {
  const response = await fetch(\`https://api.example.com/users/\${userId}\`);
  if (!response.ok) {
    throw new Error(\`Failed to fetch user: \${response.status}\`);
  }
  return await response.json();
}

// Usage
const user = await fetchUser(123);
console.log(user.name);`;

  return new Response(jsCode, {
    headers: { "Content-Type": "text/javascript" }
  });
}