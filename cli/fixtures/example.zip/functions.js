export async function handleToolCall(name, input) {
  switch (name) {
    case "ping":
      return new Response(JSON.stringify({ response: "pong" }));
    default:
      return new Response(JSON.stringify({ error: "Unknown tool" }), {
        status: 400,
      });
  }
}
